# E&P Maneuver Simulator

Mobil tarayıcıda çalışan, eğitim ve oyun amaçlı ECDIS tarzı gemi manevra simülatörü.

## v1.5

- Değiştirilebilir gemi boyu, eni, azami sürati, draft ve minimum UKC
- Gemi özelliklerine bağlı dönüş, hızlanma, durma, akıntı, rüzgâr, squat ve sığ su modeli
- Level 1 öncesi adım adım Tanıtım bölümü
- Mobil dik/yatay ekran düzeni
- PWA ve çevrimdışı çalışma
- MASTER test paketi: tüm leveller açık
- v1.6 gerçekçi harita ve kompakt portre arayüzü için yeniden paketleme

> Gerçek seyir veya köprüüstü kararlarında kullanılamaz.

Yapımcı: Engin PINAR
